local colors = require("colors")

sbar.bar({
	topmost = off,
	height = 40,
	border_width = 0,
	color = colors.bar.bg,
	boder_color = colors.bar.border,
	padding_right = 10,
	padding_left = 10,
	blur_radius = 30,
	corner_radius = 9,
	margin = 10,
	notch_width = 100,
	position = top,
	shadow = off,
	sticky = on,
	y_offset = 10,
})