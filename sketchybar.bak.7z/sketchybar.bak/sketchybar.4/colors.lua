local cat = require("catppuccin-mocha")
-- Catppuccin Macchiato palette
local colors = {
  black   = cat.crust,
	white   = cat.text,
	red     = cat.red,
	green   = cat.green,
	blue    = cat.blue,
	teal    = cat.teal,
	yellow  = cat.yellow,
	orange  = cat.peach,
	magenta = cat.mauve,
	grey    = cat.overlay1,
	transparent = cat.invisible,

  bar = {
    bg = cat.base,
    border = cat.overlay0
  },
  popup = {
    bg = cat.base,
    border = cat.lavander,
  },
  bg1 = cat.surface0,
  bg2 = cat.surface1,

  with_alpha = function(color, alpha)
		if alpha > 1.0 or alpha < 0.0 then return color end
		return (color & 0xffffff00) | (math.floor(alpha * 255.0) << 24)
	end,
  
  -- -- general bar colors
  -- bar_color   = 0x1e1e2eff,
  -- icon_color  = 0xcdd6f4ff, -- color of all icons
  -- label_color = 0xbac2deff, -- color of all labels
}

colors.bar.bg = colors.with_alpha(colors.bar.bg,0.1)

return colors