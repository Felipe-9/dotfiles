#!/usr/bin/env bash

osascript -e 'tell app "Terminal" to do script "brew upgrade"'