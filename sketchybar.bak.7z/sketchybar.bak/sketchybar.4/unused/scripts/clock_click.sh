#!/usr/bin/env bash

open -b com.apple.systempreferences /System/Library/PreferencePanes/DateAndTime.prefPane

