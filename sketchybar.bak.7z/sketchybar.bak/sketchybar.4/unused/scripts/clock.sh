#!/usr/bin/env bash

# sketchybar -m --set $NAME label="$(date '+%Y-%m-%d-T%H:%M:%S')"
sketchybar -m --set $NAME label="$(date '+%d/%m %H:%M')"

