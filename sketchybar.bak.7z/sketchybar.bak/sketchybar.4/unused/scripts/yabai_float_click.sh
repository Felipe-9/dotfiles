#!/usr/bin/env bash

yabai -m window --toggle float
sketchybar -m --trigger float_change