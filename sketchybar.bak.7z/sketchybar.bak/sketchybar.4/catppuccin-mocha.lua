return {
  base   = 0x1e1e2eff,
  mantle = 0x181825ff,
  crust  = 0x11111bff,

  text     = 0xcdd6f4ff,
  subtext0 = 0xa6adc8ff,
  subtext1 = 0xbac2deff,

  surface0 = 0x313244ff,
  surface1 = 0x45475aff,
  surface2 = 0x585b70ff,

  overlay0 = 0x6c7086ff,
  overlat1 = 0x7f849cff,
  overlay2 = 0x585b70ff,

  lavender  = 0xb4befeff,
  blue      = 0x89b4faff,
  sapphire  = 0x74c7ecff,
  sky       = 0x89dcebff,
  teal      = 0x94e2d5ff,
  green     = 0xa6e3a1ff,
  yellow    = 0xf9e2afff,
  peach     = 0xfab387ff,
  maroon    = 0xeba0acff,
  red       = 0xf38ba8ff,
  mauve     = 0xcba6f7ff,
  pink      = 0xf5c2e7ff,
  flamingo  = 0xf2cdcdff,
  rosewater = 0xf5e0dcff,

  invisible = 0x00000000,
}