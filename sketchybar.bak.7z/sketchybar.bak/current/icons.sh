#!/usr/bin/env sh

# General Icons
export LOADING=􀖇
export APPLE=􀣺
export PREFERENCES=􀺽
export ACTIVITY=􀒓
export LOCK=􀒳
export LOGOUT=
export POWER=
export REBOOT=
export SLEEP=⏾
export BELL=􀋚
export BELL_DOT=􀝗

export BATTERY=
export CPU=
export DISK=
export MEMORY=﬙
export NETWORK=
export NETWORK_DOWN=
export NETWORK_UP=

# Git Icons
export GIT_ISSUE=􀍷
export GIT_DISCUSSION=􀒤
export GIT_PULL_REQUEST=􀙡
export GIT_COMMIT=􀡚
export GIT_INDICATOR=

# Spotify Icons
export SPOTIFY_BACK=􀊎
export SPOTIFY_PLAY_PAUSE=􀊈
export SPOTIFY_NEXT=􀊐
export SPOTIFY_SHUFFLE=􀊝
export SPOTIFY_REPEAT=􀊞

# Yabai Icons
export YABAI_STACK=􀏭
export YABAI_FULLSCREEN_ZOOM=􀏜
export YABAI_PARENT_ZOOM=􀥃
export YABAI_FLOAT=􀢌
export YABAI_GRID=􀧍
