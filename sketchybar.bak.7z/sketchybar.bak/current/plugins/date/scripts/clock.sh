#!/usr/bin/env sh

sketchybar --set "$NAME" icon="$(date '+%I:%M %p')" label=""
