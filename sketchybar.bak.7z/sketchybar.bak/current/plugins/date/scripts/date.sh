#!/usr/bin/env sh

sketchybar --set "$NAME" icon="$(date '+%a %d. %b')"
