#!/bin/bash

source "$PLUGIN_DIR/date/items/calendar.sh"
source "$PLUGIN_DIR/date/items/ical.sh"
