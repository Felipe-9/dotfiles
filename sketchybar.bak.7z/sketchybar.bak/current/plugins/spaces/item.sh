#!/bin/bash

source "$PLUGIN_DIR/spaces/items/spaces.sh"
source "$PLUGIN_DIR/spaces/items/separator-left.sh"
