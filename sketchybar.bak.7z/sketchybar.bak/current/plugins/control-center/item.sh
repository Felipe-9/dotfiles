#!/bin/bash

source "$PLUGIN_DIR/brew/item.sh"
source "$PLUGIN_DIR/github/item.sh"
source "$PLUGIN_DIR/bluetooth/item.sh"
source "$PLUGIN_DIR/wifi/item.sh"
source "$PLUGIN_DIR/battery/item.sh"

source "$PLUGIN_DIR/control-center/items/divider.sh"
