#!/bin/bash

source "$PLUGIN_DIR/lock/events/lock.sh"
