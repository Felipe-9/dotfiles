#!/bin/bash

source "$PLUGIN_DIR/stats/events/toggle_stats.sh"

source "$PLUGIN_DIR/stats/items/separator-right.sh"

source "$PLUGIN_DIR/stats/items/cpu.sh"
source "$PLUGIN_DIR/stats/items/memory.sh"
source "$PLUGIN_DIR/stats/items/disk.sh"
source "$PLUGIN_DIR/stats/items/network.sh"
