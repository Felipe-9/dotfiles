-- crust,
-- text,
-- red,
-- green,
-- blue,
-- teal,
-- yellow,
-- peach,
-- mauve,
-- overlay1,
return {
  mocha = {
    crust  = 0xff11111b,
    mantle = 0xff181825,
    base   = 0xff1e1e2e,
  
    surface0 = 0xff313244,
    surface1 = 0xff45475a,
    surface2 = 0xff585b70,
  
    overlay0 = 0xff6c7086,
    overlay1 = 0xff7f849c,
    overlay2 = 0xff585b70,
    
    subtext0 = 0xffa6adc8,
    subtext1 = 0xffbac2de,
    text     = 0xffcdd6f4,
  
    lavender  = 0xffb4befe,
    blue      = 0xff89b4fa,
    sapphire  = 0xff74c7ec,
    sky       = 0xff89dceb,
    teal      = 0xff94e2d5,
    green     = 0xffa6e3a1,
    yellow    = 0xfff9e2af,
    peach     = 0xfffab387,
    maroon    = 0xffeba0ac,
    red       = 0xfff38ba8,
    mauve     = 0xffcba6f7,
    pink      = 0xfff5c2e7,
    flamingo  = 0xfff2cdcd,
    rosewater = 0xfff5e0dc,
  },
  latte = {
    crust  = 0xffdce0e8,
    mantle = 0xffe6e9ef,
    base   = 0xffeff1f5,

    surface0 = 0xffccd0da,
    surface1 = 0xffbcc0cc,
    surface2 = 0xffacb0be,
  
    overlay0 = 0xff9ca0b0,
    overlay1 = 0xff8c8fa1,
    overlay2 = 0xff7c7f93,
  
    subtext0 = 0xff6c6f85,
    subtext1 = 0xff5c5f77,
    text     = 0xff4c4f69,
  
    lavender  = 0xff7287fd,
    blue      = 0xff1e66f5,
    sapphire  = 0xff209fb5,
    sky       = 0xff04a5e5,
    teal      = 0xff179299,
    green     = 0xff40a02b,
    yellow    = 0xffdf8e1d,
    peach     = 0xfffe640b,
    maroon    = 0xffe64553,
    red       = 0xffd20f39,
    mauve     = 0xff8839ef,
    pink      = 0xffea76cb,
    flamingo  = 0xffdd7878,
    rosewater = 0xffdc8a78,
  },

  invisible = 0x00000000,

  with_alpha = function(color, alpha)
    if alpha > 1.0 or alpha < 0.0 then return color end
    return (color & 0x00ffffff) | (math.floor(alpha * 255.0) << 24)
  end
}