return {
  text = "SF Pro", -- Used for text
  numbers = "SFMono Nerd Font", -- Used for numbers

  -- Unified font style map
  style_map = {
    ["Regular"] = "Regular",
    ["Semibold"] = "Semibold",
    ["Bold"] = "Bold",
    ["Heavy"] = "Heavy",
    ["Black"] = "Black",
  }
}
