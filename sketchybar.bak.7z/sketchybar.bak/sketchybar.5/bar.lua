local colors = require("colors")

-- Equivalent to the --bar domain
sbar.bar({
  topmost = off,
  height = 25,
  border_width = 0,
  color = colors.bar.bg,
  boder_color = colors.bar.border,
  padding_right = 10,
  padding_left = 10,
  blur_radius = 5,
  corner_radius = 30,
  margin = 10,
  notch_width = 300,
  position = top,
  shadow = off,
  sticky = on,
  y_offset = 7,
})
