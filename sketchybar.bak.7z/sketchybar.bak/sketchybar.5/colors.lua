local cat = require("catppuccin")
-- Catppuccin mocha palette

return {
  black   = cat.mocha.crust,
  white   = cat.mocha.text,
  red     = cat.mocha.red,
  green   = cat.mocha.green,
  blue    = cat.mocha.blue,
  teal    = cat.mocha.teal,
  yellow  = cat.mocha.yellow,
  orange  = cat.mocha.peach,
  magenta = cat.mocha.mauve,
  grey    = cat.mocha.overlay1,
  transparent = cat.invisible,

  bar = {
    bg = cat.with_alpha(cat.mocha.base,0.6),
    border = cat.mocha.overlay0
  },
  popup = {
    bg = cat.with_alpha(cat.mocha.base,0.9),
    border = cat.mocha.lavender,
  },
  bg1 = cat.with_alpha(cat.mocha.surface0,0.7),
  bg2 = cat.with_alpha(cat.mocha.surface1,0.9),

  with_alpha = cat.with_alpha
}