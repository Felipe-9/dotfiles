return {
  font = "SF Pro",
  paddings = 3,
}
